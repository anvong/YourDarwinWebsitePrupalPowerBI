/**
 * @file
 * Global utilities.
 *
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.custom_barrio = {
    attach: function (context, settings) {

    }
  };

})(Drupal);
;
;
